<?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemUsuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Cedula del usuario</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="cedula" value="<?php echo e(old('cedula', $itemUsuario->cedula)); ?>" readonly>
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Nombre del usuario</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $itemUsuario->name)); ?>" readonly>
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Apellido del usuario</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name', $itemUsuario->last_name)); ?>" readonly>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Fecha de inicio</label>
        <div class="col-sm-6">
            <input type="date" class="form-control" name="fecha_inicio" value="<?php echo e(old('fecha_inicio', $permiso_profesor->fecha_inicio)); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Fecha Fin</label>
        <div class="col-sm-6">
            <input type="date" class="form-control" name="fecha_fin" value="<?php echo e(old('fecha_fin', $permiso_profesor->fecha_fin)); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Hora Inicio</label>
        <div class="col-sm-6">
            <input type="time" class="form-control" name="hora_inicio" value="<?php echo e(old('hora_inicio', $permiso_profesor->hora_inicio)); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Hora Fin</label>
        <div class="col-sm-6">
            <input type="time" class="form-control" name="hora_fin" value="<?php echo e(old('hora_fin', $permiso_profesor->hora_fin)); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Descripción</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="descripcion" value="<?php echo e(old('descripcion', $permiso_profesor->descripcion)); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Tipo Permiso</label>
        <div class="col-sm-6">
        <?php echo Form::select('tipo_permiso[]',$tipo_permiso, null,['class' => 'form-control']);; ?>

            <!--
            <input type="text" class="form-control" name="tipo_permiso" value="<?php echo e(old('tipo_permiso', $permiso_profesor->tipo_permiso)); ?>">
        -->
        </div>
    </div>
    <div class="form-group row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Archivo Adjunto</label>
        <div class="col-sm-6">
            <input type="file" class="form-control" name="file" value="<?php echo e(old('file', $permiso_profesor->file)); ?>">
        </div>
    </div>



<?php /**PATH C:\laragon\www\tesis2\resources\views/permiso_profesors/_form.blade.php ENDPATH**/ ?>