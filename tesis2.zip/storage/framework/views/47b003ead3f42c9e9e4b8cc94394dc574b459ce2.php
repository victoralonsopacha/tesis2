
<div class="row">
    <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Nombres:</strong>
            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Apellidos:</strong>
            <?php echo Form::text('last_name', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Cédula:</strong>
            <?php echo Form::text('cedula', null, array('placeholder' => 'Cédula','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Contraseña:</strong>
            <?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>

        </div>

        <div class="form-group">
            <strong>Confirmar Contraseña Password:</strong>
            <?php echo Form::password('confirm-password', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>

        </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Email:</strong>
            <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Tipo Relación Laboral:</strong>
            <?php echo Form::select('tipo_relacion_laboral[]', $tipo_relacion_laboral, null,array('class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Jornada:</strong>
            <?php echo Form::select('jornada[]', $jornada, null,array('class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Rol:</strong>
            <?php echo Form::select('roles[]', $roles,$userRole, array('class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Fecha de Ingreso:</strong>
            <?php echo Form::date('fecha_ingreso', null,['class' => 'form-control']); ?>

        </div>
    </div>
</div>

<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/users/_form.blade.php ENDPATH**/ ?>