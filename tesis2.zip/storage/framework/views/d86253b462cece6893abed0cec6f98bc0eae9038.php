<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php echo $__env->yieldContent('contentheader_title', ''); ?>
        <small><?php echo $__env->yieldContent('contentheader_description'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(trans('adminlte_lang::message.level')); ?></a></li>
        <li class="active"><?php echo e(trans('adminlte_lang::message.here')); ?></li>
    </ol>
</section><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/vendor/adminlte/layouts/partials/contentheader.blade.php ENDPATH**/ ?>