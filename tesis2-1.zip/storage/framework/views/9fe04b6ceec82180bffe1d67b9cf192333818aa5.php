Página no encontrada
<br>
<a href="/">Volver al inicio</a><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/errors/404.blade.php ENDPATH**/ ?>