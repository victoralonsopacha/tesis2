

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<h1>TIMBRAR PERMISO</h1>
<h4>Por favor ingrese su numero de cedula para timbrar</h4>
<br>
<?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>

<div class="pull-right">
    <form class="form-inline my-2 my-lg-0 float-right">
        <label for="">Buscar por cedula:</label>
        <input name="buscador" class="form-control me-2" type="search" placeholder="Ingrese una cedula" aria-label="Search">
        <button class="btn btn-success" type="submit">Buscar</button>
    </form>
</div>
<br><br>
<div class="panel panel-default">
    <!-- Default panel contents -->
    <div class="panel-heading">Profesores</div>

        <table class="table table-responsive-md text-center">
            <thead class="thead-tomate">
            <tr>
                <th>Cedula</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Cargo</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($rol->model_id == $userItem->id): ?>
                            <?php if($rol->role_id == $role->id): ?>
                                <tr>
                                    
                                    <td><?php echo $userItem->cedula; ?></td>
                                    <td><?php echo $userItem->name; ?></td>
                                    <td><?php echo $userItem->last_name; ?></td>
                                    <td><?php echo $role->name; ?></td>
                                    <td>
                                        <form action="<?php echo e(route('timbrada_permisos.create', $userItem->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button class="btn btn-warning btn-xs">Timbrar</button>
                                        </form>
                                    </td>
                                    <td>
                                </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\tesis2\resources\views/timbrada_permisos/index.blade.php ENDPATH**/ ?>