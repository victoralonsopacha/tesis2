

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <h1>Permiso</h1>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('permiso_profesors.shows')); ?>">Regresar</a>
        </div>
        <br><br>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-warning alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <?php echo Form::model($permiso_profesor, ['method' => 'PATCH','route' => ['permiso_profesors.update', $permiso_profesor]]); ?>


        <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Fecha de Inicio:</strong>
            <?php echo Form::date('fecha_inicio',null,['class' => 'form-control','readonly']); ?>

        </div>
        <div class="form-group">
            <strong>Fecha Fin:</strong>
            <?php echo Form::date('fecha_fin', null, array('class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group">
            <strong>Hora Inicio:</strong>
            <?php echo Form::time('hora_inicio', \Carbon\Carbon::now(), array('class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group">
            <strong>Hora Fin:</strong>
            <?php echo Form::time('hora_fin', null, array('class' => 'form-control','readonly')); ?>

        </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Tipo Permiso:</strong>
            <?php echo Form::text('tipo_permiso', null, array('placeholder' => 'Descripcion','class' => 'form-control','readonly')); ?>


        </div>
        <div class="form-group">
            <strong>Descripcion:</strong>
            <?php echo Form::text('descripcion', null, array('placeholder' => 'Descripcion','class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group">
            <strong>Observacion de la desaprobacion:</strong>
            <?php echo Form::text('desaprobacion', null, array('placeholder' => 'Descripcion','class' => 'form-control','readonly')); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>



</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/permiso_profesors/show.blade.php ENDPATH**/ ?>