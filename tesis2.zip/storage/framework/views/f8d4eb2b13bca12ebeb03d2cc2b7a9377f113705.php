

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <h1>Escoger Reposicion</h1>

    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('tiempo_reposicions.store')); ?>">
        <?php echo csrf_field(); ?>
        

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Cedula del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="cedula" value="<?php echo e($cedula=auth()->user()->cedula); ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Nombre del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="nombre" value="<?php echo e($cedula=auth()->user()->name); ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Apellido del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="apellido" value="<?php echo e($cedula=auth()->user()->last_name); ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Cantidad de Tiempo</label>
            <div class="col-sm-2">
                <input type="time" class="form-control" name="horas" value="<?php echo e(old('horas', $tiempo_reposicions->horas)); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Dia que desea reponer</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" name="fecha" value="<?php echo e(old('fecha', $tiempo_reposicions->fecha)); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-6">
                <button type="submit" class="btn btn-info">Guardar</button>
            </div>
        </div>
        
  
        


        
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/tiempo_reposicions/create.blade.php ENDPATH**/ ?>