

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <h1>GESTION USUARIOS</h1>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('users.inactivos')); ?>">Ver usuarios inactivos</a>
        </div>
        <div class="pull-right">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-danger">Agregar nuevo usuario</a>
        </div>
        <br><br>

    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if($usersl->isempty()): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="alert alert-warning" role="alert">
                                No existen registros !!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
                <div class="panel panel-default">
                    <table class="table table-responsive-md">
                        <thead class="thead-tomate">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>Estado</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($rol->model_id == $users->id): ?>
                                            <?php if($rol->role_id == $role->id): ?>
                                                <tr>
                                                    <td><?php echo $users->id; ?></td>
                                                    <td><?php echo $users->name." ".$users->last_name; ?></td>
                                                    <td><?php echo $users->email; ?>

                                                    <td><?php echo $role->name; ?></td>
                                                    <td><span class="label label-primary">Activo</span></td>
                                                    <td>
                                                        <a class="btn btn-success btn-xs" href="<?php echo e(route('users.edit', $users->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                    </td>
                                                    <td>
                                                        <form action="<?php echo e(route('users.deactive', $users->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                            <button class="btn btn-warning btn-xs">Desactivar</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/users/activos.blade.php ENDPATH**/ ?>