

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading">Atrasos</div>
        </div>
        <!--Seccion Validacion Fechas-->
        <div class="row">
            <?php echo Form::open(['route' => 'atrasos.buscar', 'method'=>'POST']); ?>

            <?php echo Form::token(); ?>


            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_inicio',null,['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_fin',\Carbon\Carbon::now(),['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::submit('Buscar');; ?>

            </div>
            <?php echo e(Form::close()); ?>

        </div>
        <br>
        <div class="panel panel-default">
            <table class="table table-responsive-md">
                <thead class="thead-tomate">
                <tr>
                    <th>Fecha</th>
                    <th>Hora Entrada</th>
                    <th>Hora Salida</th>
                    <th>Retraso de Jornada</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $atrasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atraso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $atraso->fecha; ?></td>
                        <td><?php echo $atraso->hora_entrada; ?></td>
                        <td><?php echo $atraso->hora_salida; ?></td>
                        <td><?php echo $atraso->retraso_jornada; ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div><!--container-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/atrasos/index.blade.php ENDPATH**/ ?>