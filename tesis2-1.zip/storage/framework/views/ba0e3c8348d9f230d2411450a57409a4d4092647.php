Error Personalizado
<br>
<a href="/">Volver al inicio</a><?php /**PATH C:\laragon\www\tesis2\resources\views/errors/404.blade.php ENDPATH**/ ?>