<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center"><b>Dias de Reposicion</b></div>
        </div>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <a class="btn btn-primary" href="<?php echo e(route('tiempo_reposicions.index_inspector')); ?>">Regresar</a>
                </div>
            </div>
        </div>
        <br>
        <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="panel panel-default">
            <!-- Default panel contents -->

            <div class="panel-heading">Usuario: <?php echo e($user->name.' '.$user->last_name); ?></div>
            <!-- Table -->

            <table class="table table-responsive-md text-center">
                
                <tr>
                    <th>Nr.</th>
                    <th>Fecha</th>
                    <th>Hora Propuesta</th>
                    <th>Estado</th>
                    <th COLSPAN=2>Acción</th>
                </tr>
                
                <?php
                $i=1;
                ?>
                <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reposicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($reposicion->fecha); ?></td>
                        <td><?php echo e($reposicion->horas); ?></td>
                        <?php if($reposicion->estado == 1): ?>
                            <td><span class="label label-warning">Aprobado</span></td>
                        <?php elseif($reposicion->estado == 2): ?>
                            <td><span class="label label-info">Reprobado</span></td>
                        <?php endif; ?>
                        <?php if($reposicion->estado == 0): ?>
                        <td></td>
                            <td>
                                <form action="<?php echo e(route('tiempo_reposicions.active', $reposicion->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-success btn-xs">
                                        <span aria-hidden="true" class="glyphicon glyphicon-ok"></span>Aceptar</button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(route('tiempo_reposicions.desactive', $reposicion->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas rechazar esta solicitud?')">
                                        <span aria-hidden="true" class="glyphicon glyphicon-remove"></span>Rechazar</button>
                                </form>
                            </td>
                        <?php endif; ?>    
                        

                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
            <nav aria-label="..." class="text-center">
                <?php echo e($consulta->links()); ?>

            </nav>
        </div><!--/.panel-default-->
    </div><!--/.container-fluid-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/tiempo_reposicions/ver_dias.blade.php ENDPATH**/ ?>