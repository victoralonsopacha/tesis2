<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <h1>Timbrar Permiso</h1>
    <div class="pull-left">
        <a class="btn btn-primary" href="<?php echo e(route('timbrada_permisos.index')); ?>">Regresar</a>
    </div><br><br>

    <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('timbrada_permisos.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Cedula del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="cedula" value="<?php echo e($consultaItem->cedula); ?>" readonly>
            </div>
        </div>

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Nombre del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="name" value="<?php echo e($consultaItem->name); ?>" readonly>
            </div>
        </div>

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Apellido del usuario</label>
            <div class="col-sm-2">
                <input type="text" class="form-control" name="last_name" value="<?php echo e($consultaItem->last_name); ?>" readonly>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">hora</label>
            <div class="col-sm-6">
                <input type="time" class="form-control" name="hora" value="<?php echo e($fecha_hora->format('H:i:s')); ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Fecha</label>
            <div class="col-sm-6">
                <input type="date" class="form-control" name="fecha" value="<?php echo e($fecha_hora->format('Y-m-d')); ?>" readonly>
            </div>
        </div>

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Tipo Permiso</label>
            <div class="col-sm-6">
                <?php echo Form::select('tipo_permiso[]', $tipo_permiso,$tipo_permiso,['class' => 'form-control']);; ?>

            </div>
        </div>

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Descripción</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="observacion">
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-6">
                <input type="text" class="form-control" name="estado" value='0' style="visibility:hidden">
            </div>
        </div>

        <button type="submit" class="btn btn-success">Timbrar</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/timbrada_permisos/create.blade.php ENDPATH**/ ?>