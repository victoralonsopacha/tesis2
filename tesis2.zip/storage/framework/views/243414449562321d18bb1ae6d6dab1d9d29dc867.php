

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

 
<?php $__env->startSection('main-content'); ?>
    <h1>DIAS DE REPOSICION</h1>

    <div class="panel panel-default">
        <!-- Default panel contents -->
        
        <div class="panel-heading">Profesores</div>
        <!-- Table -->


       
        
            
        <table class="table table-responsive-md text-center">
            <thead class="thead-tomate">
            <tr>
                <th>Cedula</th>
                <th>Horas</th>
                <th>Fecha</th>
            </tr>
            </thead>

            <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
           
                <tr>
                    <td><?php echo e($consultaitem->cedula); ?></td>
                    <td><?php echo e($consultaitem->horas); ?></td>
                    <td><?php echo e($consultaitem->fecha); ?></td>
                    <td>
                </tr>
           
            </tbody>
        


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
    </table>
    </div>
    <a class="btn btn-primary" href="<?php echo e(route('tiempo_reposicions.index_inspector')); ?>">Regresar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/tiempo_reposicions/ver_dias.blade.php ENDPATH**/ ?>