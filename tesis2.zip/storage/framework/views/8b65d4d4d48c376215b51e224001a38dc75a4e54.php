

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Timbrar Permiso</div>
        </div>

    <div class="pull-left">
        <a class="btn btn-primary" href="<?php echo e(route('timbrada_permisos.index')); ?>">Regresar</a>
    </div><br><br>

    <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <br>
        <form method="POST" action="<?php echo e(route('timbrada_permisos.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                        <strong>Nombre del Usuario:</strong>
                        <input type="text" class="form-control" name="name" value="<?php echo e($consultaItem->name); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Apellido del Usuario:</strong>
                        <input type="text" class="form-control" name="last_name" value="<?php echo e($consultaItem->last_name); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Cédula:</strong>
                        <input type="text" class="form-control" name="cedula" value="<?php echo e($consultaItem->cedula); ?>" readonly>
                    </div>

                </div><!--/.col-md-6-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                        <strong>Fecha:</strong>
                        <input type="date" class="form-control" name="fecha" value="<?php echo e($fecha_hora->format('Y-m-d')); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Hora:</strong>
                        <input type="time" class="form-control" name="hora" value="<?php echo e($fecha_hora->format('H:i:s')); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Tipo Permiso:</strong>
                        <?php echo Form::select('tipo_permiso[]', $tipo_permiso,$tipo_permiso,['class' => 'form-control']);; ?>

                    </div>
                    <div class="form-group">
                        <strong>Observación:</strong>
                        <input type="text" class="form-control" name="observacion">
                    </div>
                </div><!--/.col-md-6-->
            </div><!--/.row-->
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-success">Timbrar</button>
                </div>
        </form><!--/.form-->
    </div><!--/.container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/timbrada_permisos/creates.blade.php ENDPATH**/ ?>