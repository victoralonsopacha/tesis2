

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <h2>PERMISOS APROBADOS</h2>
    <div class="pull-left">
        <a href="<?php echo e(route('permiso_profesors.shows')); ?>"
           class="btn btn-primary">Regresar</a>
    </div>
    <div class="pull-right">
        <a class="btn btn-danger" href="<?php echo e(route('permiso_profesors.create')); ?>">Crear Nuevo Permiso</a>
    </div>
    <br><br><br>
        <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <?php echo Form::open(['route' => 'permiso_profesors.buscarA', 'method'=>'POST']); ?>

            <?php echo Form::token(); ?>

            <div class="col-sm-1 col-lg-1">
                <strong>De:</strong>
            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_inicio',null,['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-1 col-lg-1">
                <strong>Hasta:</strong>
            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_fin',\Carbon\Carbon::now(),['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-3 col-lg-3">
                <button type="submit" class="btn btn-success">Buscar</button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
        <!-- /.row -->

    <?php if($permisos->isEmpty()): ?>
        <div class="alert alert-danger" role="alert">No existen registros actualmente</div>
    <?php else: ?>
            <br>
        <?php echo $__env->make('permiso_profesors.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/permiso_profesors/index.blade.php ENDPATH**/ ?>