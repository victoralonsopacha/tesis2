

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <h1>TIMBRADAS DE PERMISOS</h1>
    <h2>Aqui puede ver las timbradas de los usuarios que registraron sus salidas y entradas</h2>
        <div class="pull-right">
        <form class="form-inline my-2 my-lg-0 float-right">
            <label for="">Buscar por cedula:</label>
        <input name="buscador" class="form-control me-2" type="search" placeholder="Ingrese una cedula" aria-label="Search">
        <button class="btn btn-success" type="submit">Buscar</button>
        </form>
        </div>
    <br><br>
    <?php if($usersl->isEmpty()): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="alert alert-warning" role="alert">
                                No existen registros!!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>

    <div class="panel panel-default">
        <!-- Default panel contents -->
        <!-- Table -->

            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Cedula</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Cargo</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rol->model_id == $userItem->id): ?>
                                <?php if($rol->role_id == $role->id): ?>
                                <tr>
                                    <td><?php echo $userItem->cedula; ?></td>
                                    <td><?php echo $userItem->name; ?></td>
                                    <td><?php echo $userItem->last_name; ?></td>
                                    <td><?php echo $role->name; ?></td>

                                    <td>

                                        <a class="btn btn-primary" href="<?php echo e(route('consolidado_individual.calcular', $userItem)); ?>">VER</a>
                                    </td>
                                    <td>
                                </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/consolidado_permisos/index.blade.php ENDPATH**/ ?>