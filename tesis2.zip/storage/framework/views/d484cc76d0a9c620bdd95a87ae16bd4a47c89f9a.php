<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center"><b>Permisos</b></div>
        </div>
    <h4>Este módulo permite aprobar o rechazar los permisos solicitados</h4>
    <br>
    <form method="POST" action="<?php echo e(route('permisos.find')); ?>" class="form-inline my-2 my-lg-0 pull-right">
        <?php echo csrf_field(); ?>
        <strong>Buscar por:</strong>
        <div class="form-group">
            <?php echo Form::select('estado[]',$estado, null,['class' => 'form-control']);; ?>

        </div>
        <input name="buscador" class="form-control me-2" type="number" placeholder="Cédula" aria-label="Search">
        <button class="btn btn-success" type="submit">Buscar</button>
    </form>
    <br><br>
    <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($permisosl->isempty()): ?>
            <?php echo $__env->make('partials.validationAlertempty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
        <div class="panel panel-default">
            <!-- Default panel contents -->
            <div class="panel-heading">Permisos</div>
            <!-- Table -->
            <table class="table table-responsive-md text-center">
                <tbody>
                    <thead class="thead-tomate">
                    <tr>
                        <th>Nr.</th>
                        <th>Nombres y Apellidos</th>
                        <th>Cédula</th>
                        <th>Fecha Inicio</th>
                        <th>Hora Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Hora Fin</th>
                        <th>Estado</th>
                        <th>Justificar</th>
                    </tr>
                    </thead>
                </tbody>
                <?php
                    $i=1;
                ?>
                <?php $__currentLoopData = $permisosl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permisoItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($permisoItem->cedula == $user->cedula): ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td><?php echo $user->name.' '.$user->last_name; ?></td>
                            <td><?php echo $permisoItem->cedula; ?></td>
                            <td><?php echo $permisoItem->fecha_inicio; ?></td>
                            <td><?php echo $permisoItem->hora_inicio; ?></td>
                            <td><?php echo $permisoItem->fecha_fin; ?></td>
                            <td><?php echo $permisoItem->hora_fin; ?></td>
                            <?php if($permisoItem->estado == 1): ?>
                                <td><span class="label label-success">Aprobado</span></td>
                            <?php elseif($permisoItem->estado == 2): ?>
                                <td><span class="label label-warning">Rechazado</span></td>
                                <td>
                                    <a class="btn btn-primary btn-xs" href="<?php echo e(route('permisos.justificar', $permisoItem->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                </td>
                            <?php else: ?>
                                <td><span class="label label-danger">Pendiente</span></td>
                                <td>
                                    <a class="btn btn-danger btn-xs" href="<?php echo e(route('permisos.justificar', $permisoItem->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody><!--/.table-->
            </table><!--/.table-->
            <nav aria-label="..." class="text-center">
                <?php echo e($permisosl->links()); ?>

            </nav>
        </div><!--/.panel-->
        <?php endif; ?>
    </div><!--/.container-fluid-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permisos/index.blade.php ENDPATH**/ ?>