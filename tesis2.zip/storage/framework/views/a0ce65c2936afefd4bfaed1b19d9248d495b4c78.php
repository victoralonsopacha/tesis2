

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Crear Permisos</div>
        </div>
        <h4>Este módulo te permite crear un permiso</h4>
        <br>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('permiso_profesors.shows')); ?>">Regresar</a>
        </div>
        <br><br><br>
        <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('permiso_profesors.store')); ?>" method="POST" accept-charset="UTF-8" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('permiso_profesors._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-success">Crear Permiso</button>
        </div>
        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permiso_profesors/create.blade.php ENDPATH**/ ?>