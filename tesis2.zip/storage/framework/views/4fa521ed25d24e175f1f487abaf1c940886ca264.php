<table>
    <thead>
    <tr>
        <th>Cedula</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Fecha</th>
        <th>Hora</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($consulta->cedula); ?></td>
            <td><?php echo e($consulta->name); ?></td>
            <td><?php echo e($consulta->last_name); ?></td>
            <td><?php echo e($consulta->fecha); ?></td>
            <td><?php echo e($consulta->hora); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/excel/permisos.blade.php ENDPATH**/ ?>