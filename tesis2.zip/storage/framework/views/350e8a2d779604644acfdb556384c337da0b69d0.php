

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <h1>MIS PERMISOS</h1>
    <div class="pull-left">
        <a href="<?php echo e(route('permiso_profesors.index', ['permiso_profesor' => $permiso_profesor=auth()->user()->cedula])); ?>"
           class="btn btn-success">Permisos Aprobados</a>
        <a href="<?php echo e(route('permiso_profesors.index1', ['permiso_profesor' => $permiso_profesor=auth()->user()->cedula])); ?>"
           class="btn btn-info">Permisos Desaprobados</a>
    </div>
    <div class="pull-right">
        <a class="btn btn-warning" href="<?php echo e(route('permiso_profesors.create')); ?>">Crear Nuevo Permiso</a>
    </div>
    <br><br><br>
    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php echo Form::open(['route' => 'permiso_profesors.buscar', 'method'=>'POST']); ?>

        <?php echo Form::token(); ?>

        <div class="col-sm-1 col-lg-1">
            <strong>De:</strong>
        </div>
        <div class="col-sm-3 col-lg-3">
            <?php echo Form::date('fecha_inicio',null,['class' => 'form-control']); ?>

        </div>
        <div class="col-sm-1 col-lg-1">
            <strong>Hasta:</strong>
        </div>
        <div class="col-sm-3 col-lg-3">
            <?php echo Form::date('fecha_fin',\Carbon\Carbon::now(),['class' => 'form-control']); ?>

        </div>
        <div class="col-sm-3 col-lg-3">
        <button type="submit" class="btn btn-success">Buscar</button>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
    <!-- /.row -->
    <?php if($permisos->isEmpty()): ?>
        <h4>No existen registros</h4>
    <?php else: ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <br>
        <div class="panel panel-default">
        <div class="panel-heading">Permisos</div>
            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Nr.</th>
                    <th>Fecha Inicio</th>
                    <th>Hora Inicio</th>
                    <th>Fecha Finalizacion</th>
                    <th>Hora Finalizacion</th>
                    <th>Estado</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $permiso->fecha_inicio; ?></td>
                    <td><?php echo $permiso->hora_inicio; ?></td>
                    <td><?php echo $permiso->fecha_fin; ?></td>
                    <td><?php echo $permiso->hora_fin; ?></td>
                    <?php if($permiso->estado == '0'): ?>
                    <td><span class="label label-danger">Pendiente</span></td>
                        <td>
                            <a href="<?php echo e(route('permiso_profesors.edit', $permiso)); ?>" class="btn btn-xs btn-danger"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                        </td>
                    <?php elseif($permiso->estado == '1'): ?>
                        <td><span class="label label-success">Aprobado</span></td>
                        <td>
                            <a href="<?php echo e(route('permiso_profesors.show', $permiso)); ?>" class="btn btn-xs btn-success"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        </td>
                    <?php elseif($permiso->estado == '2'): ?>
                        <td><span class="label label-info">Desaprobado</span></td>
                        <td>
                            <a href="<?php echo e(route('permiso_profesors.show', $permiso)); ?>" class="btn btn-xs btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/permiso_profesors/shows.blade.php ENDPATH**/ ?>