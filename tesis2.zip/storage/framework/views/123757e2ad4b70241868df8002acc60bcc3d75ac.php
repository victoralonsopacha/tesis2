<div class="row">
    <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Nombres:</strong>
            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Apellidos:</strong>
            <?php echo Form::text('last_name', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <strong>Cedula:</strong>
            <?php echo Form::text('cedula', null, array('placeholder' => 'Cedula','class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <strong>Contraseña:</strong>
            <?php echo Form::password('password', array('placeholder' => 'Contraseña','class' => 'form-control')); ?>

            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-xs-6 col-sm-6 col-md-6">
        <div class="form-group">
            <strong>Email:</strong>
            <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group">
            <strong>Tipo Relacion Laboral:</strong>
            <?php echo Form::select('tipo_relacion[]', $tipo_relacion,'',['class' => 'form-control']);; ?>

        </div>
        <div class="form-group">
            <strong>Rol:</strong>
            <?php echo Form::select('roles[]',$userRole,null, array('class' => 'form-control','readonly')); ?>

        </div>
        <div class="form-group">
            <strong>Fecha de Ingreso:</strong>
            <?php echo Form::date('fecha_ingreso', null,['class' => 'form-control','readonly']); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/perfiles/form.blade.php ENDPATH**/ ?>