

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">
                <b>Timbradas de Permisos</b>
            </div>
        </div>
        <h4><p class="text-left">Este módulo permite ver las timbradas de los usuarios que registraron su salida y entrada del permiso autorizado</p></h4>
        <div class="pull-right">
            <form class="form-inline my-2 my-lg-0 float-right">
                <label>Buscar Por:</label>
                <div class="form-group">
                    <input name="nombre" class="form-control me-2" type="text" placeholder="Nombre" aria-label="Search">
                </div>
                <div class="form-group">
                    <input name="cedula" class="form-control me-2" type="search" placeholder="Cédula" aria-label="Search">
                </div>
                <button class="btn btn-success" type="submit">Buscar</button>
            </form>
        </div>
        <br><br>
        <?php if($usersl->isEmpty()): ?>
            <?php echo $__env->make('partials.validationAlertempty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <div class="panel panel-default">
                <!-- Default panel contents -->
                <!-- Table -->
                <div class="panel-heading text-center"><b>Usuarios</b></div>
                    <table class="table table-responsive-md text-center">
                        <thead class="thead-tomate">
                        <tr>
                            <th>Nr.</th>
                            <th>Nombres y Apellidos</th>
                            <th>Cédula</th>
                            <th>Cargo</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i=1;
                        ?>
                        <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($rol->model_id == $userItem->id): ?>
                                        <?php if($rol->role_id == $role->id): ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $userItem->name.' '.$userItem->last_name; ?></td>
                                            <td><?php echo $userItem->cedula; ?></td>
                                            <td><?php echo $role->name; ?></td>
                                            <td>
                                                <a class="btn btn-primary btn-xs" href="<?php echo e(route('consolidado_permisos.calcular', $userItem)); ?>">Seleccionar</a>
                                            </td>
                                            <td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
        <?php endif; ?>
        </div><!--/.panel-default-->
    </div><!--/.container-fluid-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/consolidado_permisos/index.blade.php ENDPATH**/ ?>