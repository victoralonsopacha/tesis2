

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Propuestas de Reposiciones de Atrasos</div>
        </div>
        <div class="row">
            <div class="col-md-3">
            <label for="">Atrasos Total: </label>
                <?php echo $totalHoras; ?>

            </div>
            <div class="col-md-3">
            <label for="">Reposiciones Total: </label>
                <?php echo $totalReposicion; ?>                
            </div>
            <div class="col-md-3">
            <label for="">Reposiciones Total: </label>
                <?php
                $horaInicio = new DateTime($totalHoras);
                $horaTermino = new DateTime($totalReposicion);

                $interval = $horaInicio->diff($horaTermino);
                echo $interval->format('%H:%i:%s');
                ?> 
            </div>
        </div>
                  

        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <b>Usuario: <?php echo e(auth()->user()->name.' '.auth()->user()->last_name); ?></b>
            </div>
            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Nr.</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Estado</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $i=1;
                ?>
                <?php $__currentLoopData = $tiempos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiempo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $tiempo->fecha; ?></td>
                        <td><?php echo $tiempo->horas; ?></td>
                        <?php if($tiempo->estado == 1): ?>
                            <td><span class="label label-success">Aprobado</span></td>
                        <?php elseif($tiempo->estado == 2): ?>
                            <td><span class="label label-info">Rechazado</span></td>
                        <?php elseif($tiempo->estado == 0): ?>
                            <td><span class="label label-danger">Pendiente</span></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </tbody><!--/.tbody-->
            </table><!--/.table-->
            <nav aria-label="..." class="text-center">
                <?php echo e($tiempos->links()); ?>

            </nav>
        </div><!--/.panel-->
    </div><!--/.container-->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/tiempo_reposicions/shows.blade.php ENDPATH**/ ?>