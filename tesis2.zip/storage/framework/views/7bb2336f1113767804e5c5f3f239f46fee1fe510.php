

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
<h4>Por favor seleccione su usuario para proceder a timbrar</h4>
<br>
<?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="pull-right">
    <form class="form-inline my-2 my-lg-0 float-right">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputName2">Buscar Por:</label>
            <input name="nombre" class="form-control me-2" type="text" placeholder="Nombre" aria-label="Search">
        </div>
        <div class="form-group">
            <input name="cedula" class="form-control me-2" type="number" placeholder="Cédula" aria-label="Search">
        </div>
        <button type="submit" class="btn btn-success">Buscar</button>
    </form>
</div>
<br><br>
    <?php if($usersl->isempty()): ?>
        <?php echo $__env->make('partials.validationAlertempty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <div class="panel panel-default">
        <!-- Default panel contents -->
        <div class="panel-heading">Profesores</div>

            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Nr.</th>
                    <th>Nombres y Apellidos</th>
                    <th>Cédula</th>
                    <th>Cargo</th>
                    <th>Acción</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i=1;
                ?>
                <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rol->model_id == $userItem->id): ?>
                                <?php if($rol->role_id == $role->id): ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo $userItem->name.' '.$userItem->last_name; ?></td>
                                        <td><?php echo $userItem->cedula; ?></td>
                                        <td><?php echo $role->name; ?></td>
                                        <td>
                                            <form action="<?php echo e(route('timbrada_permisos.create', $userItem->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button class="btn btn-primary btn-xs">Seleccionar</button>
                                            </form>
                                        </td>
                                        <td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
    <?php endif; ?>
    </div><!--/.container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/timbrada_permisos/index.blade.php ENDPATH**/ ?>