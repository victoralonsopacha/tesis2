<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <strong>Creado por Victor Pacha y Jazmin Villamarin </strong>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 </strong>
</footer>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\tesis2\resources\views/vendor/adminlte/layouts/partials/footer.blade.php ENDPATH**/ ?>