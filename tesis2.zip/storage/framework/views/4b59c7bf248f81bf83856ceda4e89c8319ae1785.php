

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

 
<?php $__env->startSection('main-content'); ?>
    <h1>DIAS DE REPOSICION</h1>
    <h4>En este modulo puede observar los dias que el profesor a escogido para reponer sus sus atrasos</h4>
    <br>
    <div class="panel panel-default">
        <!-- Default panel contents -->
        <form class="form-inline my-2 my-lg-0 float-right">
            <input name="buscador" class="form-control me-2" type="search" placeholder="Ingrese una cedula" aria-label="Search">
            <button class="btn btn-success" type="submit">Buscar</button>
          </form>
        <div class="panel-heading">Profesores</div>
        <!-- Table -->


        <?php if($usersl->isEmpty()): ?>
            <p>No existen profesores</p>
        <?php else: ?>
            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Cedula</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Cargo</th> 
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $userItem->cedula; ?></td>
                        <td><?php echo $userItem->name; ?></td>
                        <td><?php echo $userItem->last_name; ?></td>
                        
                        <td>
                            <a class="btn btn-primary" href="<?php echo e(route('tiempo_reposicions.ver_dias', $userItem)); ?>">VER</a>
                        </td>
                        <td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?> 

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/tiempo_reposicions/index_inspector.blade.php ENDPATH**/ ?>