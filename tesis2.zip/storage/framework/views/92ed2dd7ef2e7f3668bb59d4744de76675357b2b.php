

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <h1>CALCULO DE HORAS</h1>


    <div class="card text-center">
        <div class="card-header">
          <ul class="nav nav-tabs card-header-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="#">Profesor</a>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Cedula</label>              
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-2 col-form-label"><?php echo e($user->cedula); ?></label>
                    </div>
                </div>      
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Nombre</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-2 col-form-label"><?php echo e($user->name); ?></label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Apellido</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-2 col-form-label"><?php echo e($user->last_name); ?></label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Cargo</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-2 col-form-label"><?php echo e($user->cargo); ?></label>
                    </div>
                </div>


                <form method="POST" action="<?php echo e(route('calculo_tiempos.total2', $user)); ?>">
                    <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">INICIO</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control" name="fecha_inicio" value="'fecha_inicio'">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">FIN</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control" name="fecha_fin" value="'fecha_fin'">
                    </div>
                </div>
                <div class="col-sm-9">
                <button type="submit" class="btn btn-success"><a class="nav-link" >Calcular tiempos</a></button>

                </div>

                </form>
                
            </li>

          </ul>
        </div>
      </div>
      <br>
      <br>
<div class="col-sm-9">
<a class="btn btn-primary" href="<?php echo e(route('calculo_tiempos.index')); ?>">Regresar</a>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/calculo_tiempos/calcular.blade.php ENDPATH**/ ?>