<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
        .table {
            width: 100%;
            border: 1px solid #999999;
        }
    </style>
</head>
<body>
    <table class="table">    
        <h1>ESCUELA VELASCO IBARRA</h1>    
        <h2>Reporte de timbradas de usuario TIMBRADAS BIOMETRICO</h2> 
        <thead>
            <tr>
                <th>Cedula</th>
                <th>Nombre</th>
                <th>Tiempo</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>           
                    <td><?php echo e($consulta->cedula); ?></td>
                    <td><?php echo e($consulta->nombre); ?></td>
                    <td><?php echo e($consulta->tiempo); ?></td>
                    <td><?php echo e($consulta->fecha); ?></td>               
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>



<?php /**PATH C:\laragon\www\tesis2\resources\views/pdf/timbradas.blade.php ENDPATH**/ ?>