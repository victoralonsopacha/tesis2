<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Editar Permiso</div>
        </div>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('permiso_profesors.shows')); ?>">Regresar</a>
        </div>
        <br><br>

        <?php echo Form::model($permiso_profesor, ['method' => 'PATCH','accept-charset'=>'UTF-8', 'enctype'=>'multipart/form-data','route' => ['permiso_profesors.update', $permiso_profesor]]); ?>

        <?php echo Form::token(); ?>


            <div class="row">
                <?php echo $__env->make('permiso_profesors._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-success">Actualizar</button>
            </div>

                <?php echo Form::close(); ?>


        <br>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permiso_profesors/edit.blade.php ENDPATH**/ ?>