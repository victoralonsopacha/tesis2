

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <div class="panel panel-primary">
        <div class="panel-heading" style="text-align: center">Jornada</div>
    </div>
    <?php if($horarios->isEmpty()): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="alert alert-warning" role="alert">
                                No existen registros !!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <?php else: ?>
                <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="">Tu Jornada es
                    <?php echo Form::label($horario->tipo); ?> en horario de
                    <?php echo Form::label($horario->hora_entrada); ?> a
                    <?php echo Form::label($horario->hora_salida); ?>


                </span><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <!--Seccion Validacion Fechas-->
        <br>
        <div class="row">
            <?php echo Form::open(['route' => 'jornada.buscar', 'method'=>'POST']); ?>

            <?php echo Form::token(); ?>

            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_inicio',null,['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::date('fecha_fin',\Carbon\Carbon::now(),['class' => 'form-control']); ?>

            </div>
            <div class="col-sm-3 col-lg-3">
                <?php echo Form::submit('Buscar');; ?>

            </div>
            <?php echo e(Form::close()); ?>

        </div>
        <br>
        <div class="panel panel-default">
            <table class="table table-responsive-md">
                <thead class="thead-tomate">
                <tr>
                    <th>Año</th>
                    <th>Mes</th>
                    <th>Dia</th>
                    <th>Fecha</th>
                    <th>Hora Entrada</th>
                    <th>Hora Salida</th>
                    <th>Tiempo Total</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $jornadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $jornada->anio; ?></td>
                        <td><?php echo $jornada->mes_nombre; ?></td>
                        <td><?php echo $jornada->dia; ?></td>
                        <td><?php echo $jornada->fecha; ?></td>
                        <td><?php echo $jornada->hora_entrada; ?></td>
                        <td><?php echo $jornada->hora_salida; ?></td>
                        <td><?php echo $jornada->tiempo_total; ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/jornada/index.blade.php ENDPATH**/ ?>