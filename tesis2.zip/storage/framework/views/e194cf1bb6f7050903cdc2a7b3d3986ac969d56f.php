

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #3bc492">
                    <div class="caption">
                        <h3><?php echo e(count($permisos_reprobados)); ?> Permisos Reprobados</h3>
                        <h4></h4>
                        <p><a href="#" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #00acd6">
                    <div class="caption">
                        <h3><?php echo e(count($permisos_aprobados)); ?> Permisos Aprobados</h3>
                        <h4></h4>
                        <p><a href="#" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #5d59a6">
                    <div class="caption">
                        <h3> Retrasos</h3>
                        <p><a href="#" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/dashboard/profesor.blade.php ENDPATH**/ ?>