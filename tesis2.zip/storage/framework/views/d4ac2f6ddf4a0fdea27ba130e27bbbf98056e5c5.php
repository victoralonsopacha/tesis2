

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                Permisos por Aprobar
            </div>
            <div class="col-sm-4">
                Permisos Aprobados
            </div>
            <div class="col-sm-4">
                Permisos Rechazados
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\tesis2\resources\views/dashboard/inspector.blade.php ENDPATH**/ ?>