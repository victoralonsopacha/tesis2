

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('main-content'); ?>
    <h1>Escoger Tiempo a Reponer</h1>

    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('tiempo_reposicions.create')); ?>">
        <?php echo csrf_field(); ?>
        

        <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Cedula del usuario</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="cedula" value="<?php echo e($cedula=auth()->user()->cedula); ?>">
            </div>
        </div>
        
        


        <button type="submit" class="btn btn-info">Ir</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/tiempo_reposicions/index.blade.php ENDPATH**/ ?>