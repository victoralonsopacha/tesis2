

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <section style="padding-top:60px">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        Importar Excel

                        <?php if( $errors->any() ): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form id="formularioExcel" method="POST" enctype="multipart/form-data" action="<?php echo e(route('import')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="file">Escoja un archivo con extensión .xlsx</label>
                                <input id="file" type="file" name="file" class="form-control" accept="*/xlsx">
                            </div>
                            <br>
                            <button type="submit" class="btn btn-primary">Cargar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("formularioExcel").addEventListener('submit', validarExtensiones);
        });

        function validarExtensiones(evento) {
            evento.preventDefault();
            var fileInput = document.getElementById('file');
            var filePath = fileInput.value;
            var allowedExtensions = /(.xlsx)$/i;
            if(!allowedExtensions.exec(filePath)){
                alert('Por favor seleccione un archivo con extensión .xlsx');
                fileInput.value = '';
                return false;
            }else{
                this.submit();
            }
        }
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/import-form.blade.php ENDPATH**/ ?>