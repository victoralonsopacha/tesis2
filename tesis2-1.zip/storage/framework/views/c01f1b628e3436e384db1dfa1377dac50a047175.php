<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Crear Usuario</div>
        </div>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <a class="btn btn-primary" href="<?php echo e(route('users.activos')); ?>">Regresar</a>
                </div>
            </div>
        </div>
        <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('users.store')); ?>" method="POST" id="validarFormulario">
        <?php echo csrf_field(); ?>
            <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <strong>Nombres:</strong>
                    <?php echo Form::text('name', null, array('placeholder' => 'Nombres','onkeypress'=>'return soloLetras(event)','class' => 'form-control','required')); ?>

                </div>
                <div class="form-group">
                    <strong>Apellidos:</strong>
                    <?php echo Form::text('last_name', null, array('placeholder' => 'Apellidos','onkeypress'=>'return soloLetras(event)','class' => 'form-control','required')); ?>

                </div>
                <div class="form-group">
                    <strong>Cédula:</strong>
                    <?php echo Form::text('cedula', null, array('placeholder' => 'Cedula','onkeypress'=>'return soloNumeros(event)', 'class' => 'form-control','required', 'maxlength'=>'10')); ?>

                </div>
                <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <strong>Contraseña:</strong>
                    <?php echo Form::password('password', array('placeholder' => 'Contraseña','class' => 'form-control', 'required', 'minlength'=>'6')); ?>

                    <div class="help-block">Mínimo de 6 caracteres</div>
                    <?php if($errors->has('password')): ?>
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <strong>Confirmar contraseña:</strong>
                    <?php echo Form::password('password_confirmation', array('placeholder' => 'Confirmar contraseña','class' => 'form-control','required')); ?>

                </div>

            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <strong>Correo:</strong>
                    <?php echo Form::email('email', null, array('placeholder' => 'Email','class' => 'form-control','required')); ?>

                </div>
                <div class="form-group">
                    <strong>Tipo Relación Laboral:</strong>
                    <?php echo Form::select('tipo_relacion_laboral[]',$tipo_relacion_laboral, null,['class' => 'form-control','required']);; ?>

                </div>
                <div class="form-group">
                    <strong>Jornada:</strong>
                    <?php echo Form::select('jornada[]', $jornada, null,array('class' => 'form-control')); ?>

                </div>
                <div class="form-group">
                    <strong>Rol:</strong>
                    <?php echo Form::select('roles', $roles,[], array('class' => 'form-control')); ?>

                </div>
                <div class="form-group" <?php echo e($errors->has('fecha_ingreso') ? ' has-error' : ''); ?>>
                    <strong>Fecha de Ingreso:</strong>
                    <?php echo Form::date('fecha_ingreso', null,['class' => 'form-control','required']); ?>

                    <div class="help-block"></div>
                    <?php if($errors->has('fecha_ingreso')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('fecha_ingreso')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-success">Aceptar</button>
            </div>
        </div>
        </form>

    </div><!--/..container-fluid-->

    <script>
        function soloLetras(e){
            key=e.keyCode || e.which;
            teclado=String.fromCharCode(key).toLowerCase();
            letras = " áéíóúabcdefghijklmnñopqrstuvwxyz",
            especiales="8-37-38-46-164";      
            teclado_especial=false;
            for (var i in especiales){
                if(key==especiales[i]){
                    teclado_especial=true;break;
                }
            }
            if(letras.indexOf(teclado)==-1 && !teclado_especial){
                return false;
            }
        }
        function soloNumeros(e){
            key=e.keyCode || e.which;
            teclado=String.fromCharCode(key).toLowerCase();
            letras = "0123456789",
            especiales="8-37-38-46-164";      
            teclado_especial=false;
            for (var i in especiales){
                if(key==especiales[i]){
                    teclado_especial=true;break;
                }
            }
            if(letras.indexOf(teclado)==-1 && !teclado_especial){
                return false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/users/create.blade.php ENDPATH**/ ?>