<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <div class="panel panel-primary">
        <div class="panel-heading text-center"><b>Justificar Permisos</b></div>
    </div><!--/.panel-primary-->

        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('permisos.index')); ?>">Regresar</a>
        </div>
        <br><br>
        <form method="POST" action="<?php echo e(route('permisos.update', $permiso)); ?>">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-6">
                    <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <strong>Usuario:</strong>
                        <input type="text" class="form-control" value="<?php echo e($user['name'].' '.$user['last_name']); ?>" readonly>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <strong>Fecha Inicio:</strong>
                        <input type="date" class="form-control" name="fecha_inicio" value="<?php echo e(old('fecha_inicio', $permiso->fecha_inicio)); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Hora Inicio:</strong>
                        <input type="time" class="form-control" name="hora_inicio" value="<?php echo e(old('hora_inicio', $permiso->hora_inicio)); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Fecha Fin:</strong>
                        <input type="date" class="form-control" name="fecha_fin" value="<?php echo e(old('fecha_fin', $permiso->fecha_fin)); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Hora Fin:</strong>
                        <input type="time" class="form-control" name="hora_fin" value="<?php echo e(old('hora_fin', $permiso->hora_fin)); ?>" readonly>
                    </div>
                    <div class="form-group">
                         <strong>Tipo Permiso:</strong>
                         <input type="text" class="form-control" name="tipo_permiso" value="<?php echo e($permiso->tipo_permiso); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <strong>Justificación del Usuario:</strong>
                        <input type="text" class="form-control" name="descripcion" value="<?php echo e(old('descripcion', $permiso->descripcion)); ?>" readonly>
                    </div>
                </div><!--/.col-xs-6-->
                <div class="col-md-6 col-sm-6 col-6">

                    <div class="form-group">
                        <strong>Seleccionar:</strong>
                        <?php echo Form::select('estado[]',$estado, null,['class' => 'form-control']);; ?>

                    </div>

                    <div class="form-group">
                        <strong>Observación:</strong>
                        <input type="text" class="form-control" name="desaprobacion" value="<?php echo e(old('desaprobacion', $permiso->desaprobacion)); ?>" >
                    </div>
                    <?php if($permiso->file != ''): ?>
                        <div class="form-group">
                            <strong>Archivo Justificación:</strong><br>
                            <img src="<?php echo e(asset("$permiso->file")); ?>" alt="" style="width:250px;height:250px;">            
                        </div>
                    <?php endif; ?>
                </div><!--/.col-xs-6-->
            </div><!--/.row-->
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-success">Aceptar</button>
            </div><!--/.button-->
        </form>
    </div><!--/.container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permisos/justificar.blade.php ENDPATH**/ ?>