<?php if(session('error')): ?>
    <div class="alert alert-dismissible alert-danger text-center">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/partials/validationError.blade.php ENDPATH**/ ?>