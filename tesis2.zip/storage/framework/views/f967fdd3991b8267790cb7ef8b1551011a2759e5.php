

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <h1>Crear Permiso</h1>
    <div class="pull-left">
        <a class="btn btn-primary" href="<?php echo e(route('permiso_profesors.shows')); ?>">Regresar</a>
    </div>
    <br><br><br>
    <?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::open(array('route' => 'permiso_profesors.store','method'=>'POST')); ?>

        <?php echo Form::token(); ?>

        <?php echo $__env->make('permiso_profesors._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-success">Crear Permiso</button>
        </div>
        <?php echo Form::close(); ?>

 
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/permiso_profesors/create.blade.php ENDPATH**/ ?>