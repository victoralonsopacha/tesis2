@php
    echo $reposicion;
@endphp
