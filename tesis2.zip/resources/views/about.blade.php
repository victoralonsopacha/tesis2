@extends('layout')

@section('title', 'Justificiones')

@section('content')
    <h1>Justificiones</h1>
@endsection