<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Mi Informacion</div>
        </div>
        <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::model($user, ['method' => 'POST','route' => ['inspector.edit', $user->id]]); ?>

        <div class="panel panel-default">
            <table class="table">
                <tbody>
                <tr>
                    <td><strong class="col-md-4">Nombres:</strong></td>
                    <td><label class="col-md-8"><?php echo auth()->user()->name." ".auth()->user()->last_name; ?></label></td>
                </tr>
                <tr>
                    <td><strong class="col-md-4">Correo:</strong></td>
                    <td><label class="col-md-8"><?php echo auth()->user()->email; ?></label></td>
                </tr>
                <tr>
                    <td><label class="col-md-4">Cedula:</label></td>
                    <td><label class="col-md-8"><?php echo auth()->user()->cedula; ?></label></td>
                </tr>
                <tr>
                    <td><label class="col-md-4">Relacion Laboral:</label></td>
                    <td><label class="col-md-8"><?php echo auth()->user()->tipo_relacion_laboral; ?></label></td>
                </tr>
                <tr>
                    <td><label class="col-md-4">Fecha de Ingreso:</label></td>
                    <td><label class="col-md-8"><?php echo auth()->user()->fecha_ingreso; ?></label></td>
                </tr>
                </tbody>
            </table>
        </div>
        <button type="submit" class="btn btn-info">Editar Información</button>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/perfiles/inspector.blade.php ENDPATH**/ ?>