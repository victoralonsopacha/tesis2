

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <h1>TIMBRADAS REGISTRADAS</h1>
        
    <?php if(empty($consulta)): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="alert alert-warning" role="alert">
                                No existen registros!!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>

    <div class="panel panel-default">
        <!-- Default panel contents -->
        <!-- Table -->
            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Cedula</th>
                    <th>Nombre</th>
                    <th>Tiempo</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($consultaItem->cedula); ?> </td>
                            <td><?php echo e($consultaItem->nombre); ?></td>
                            <td><?php echo e($consultaItem->tiempo); ?></td>
                            <td><?php echo e($consultaItem->fecha); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
    </div>
    <?php endif; ?>
    </div>
    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views/consolidado_individual/consolidado.blade.php ENDPATH**/ ?>