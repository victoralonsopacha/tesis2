

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

 
<?php $__env->startSection('main-content'); ?>
    <h1>TIMBRADAS</h1>
    
    <div class="panel panel-default">
        <!-- Default panel contents -->
        <div class="panel-heading">Profesores</div>
        <!-- Table -->
        
            <table class="table table-responsive-md text-center">
                <thead class="thead-tomate">
                <tr>
                    <th>Cedula</th>
                    <th>Nombre</th>
                    <th>Tiempo</th>
                    <th>Fecha</th> 
                    <th></th>
                </tr>
                </thead>
                <tbody>
                 
                <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($consultaItem->cedula); ?> </td>
                        <td><?php echo e($consultaItem->nombre); ?></td>
                        <td><?php echo e($consultaItem->tiempo); ?></td>
                        <td><?php echo e($consultaItem->fecha); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
       
            <a href="<?php echo e(route('imprimir')); ?>">Imprime el archivo</a>
    </div>

    <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>">Volver a Calcular</a>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views//consolidado_individual/consolidado.blade.php ENDPATH**/ ?>