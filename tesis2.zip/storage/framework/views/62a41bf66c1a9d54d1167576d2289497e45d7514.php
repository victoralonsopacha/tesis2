

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <h1>GESTIONAR PERMISOS</h1>
    <h4>Este modulo permite gestionar la justificación de todos los permisos creados por los profesores</h4>
<br>
    <form class="form-inline my-2 my-lg-0 float-right">
        <input name="buscador" class="form-control me-2" type="search" placeholder="Ingrese una cédula" aria-label="Search">
        <button class="btn btn-success" type="submit">Buscar</button>
    </form>


    
    <!--
    <a href="<?php echo e(route('permisos.create')); ?>">Crear Permiso</a>
    -->
    
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="panel panel-default">
        <!-- Default panel contents -->
        <div class="panel-heading">Permisos</div>
        <!-- Table -->
        
                <table class="table table-responsive-md text-center">
                    <thead class="thead-tomate">
                    <tr>
                        <th>Cedula</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Hora Inicio</th>
                        <th>Hora Fin</th>
                        <th>Fecha Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Estado</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $permisosl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permisoItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo $permisoItem->cedula; ?></td>
                            <td><?php echo $permisoItem->name; ?></td>
                            <td><?php echo $permisoItem->last_name; ?></td>
                            <td><?php echo $permisoItem->hora_inicio; ?></td>
                            <td><?php echo $permisoItem->hora_fin; ?></td>
                            <td><?php echo $permisoItem->fecha_inicio; ?></td>
                            <td><?php echo $permisoItem->fecha_fin; ?></td>
                            <?php if($permisoItem->estado == '1'): ?>
                                <td><span class="label label-success">Aprobado</span></td>
                            <?php elseif($permisoItem->estado == '2'): ?>
                                <td><span class="label label-warning">Desaprobado</span></td>
                            <?php else: ?>
                                <td><span class="label label-danger">Pendiente</span></td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(route('permisos.justificar', $permisoItem)); ?>">Justificar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


        

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\tesis2\resources\views/permisos/index.blade.php ENDPATH**/ ?>