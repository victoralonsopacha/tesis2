<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <div class="panel panel-primary">
        <div class="panel-heading text-center">Dashboard</div>
    </div>

        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #3bc492">
                    <div class="caption">
                        <h3><?php echo e(count($permisos_reprobados)); ?> Permisos Reprobados</h3>
                        <h4></h4>
                        <p><a href="<?php echo e(route('permiso_profesors.index1', ['permiso_profesor' => $permiso_profesor=auth()->user()->cedula])); ?>" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #00acd6">
                    <div class="caption">
                        <h3><?php echo e(count($permisos_aprobados)); ?> Permisos Aprobados</h3>
                        <h4></h4>
                        <p><a href="<?php echo e(route('permiso_profesors.index', ['permiso_profesor' => $permiso_profesor=auth()->user()->cedula])); ?>" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail" style="background: #5d59a6">
                    <div class="caption">
                        <h3><?php echo e(count($atrasos)); ?> Atrasos</h3>
                        <p><a href="<?php echo e(route('atrasos.index')); ?>" class="btn btn-primary" role="button">Ver detalles</a>
                    </div>
                </div>
            </div>
        </div>

    </div><!--div container fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/dashboard/profesor.blade.php ENDPATH**/ ?>