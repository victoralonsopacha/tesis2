

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
    <h4>En este módulo puede observar todos los días que profesores han escogido para reponer sus atrasos</h4>
    <br>
        <div class="pull-right">
        <form class="form-inline my-2 my-lg-0 ">
            <strong>Buscar por:</strong>
            <input name="cedula" class="form-control me-2" type="search" placeholder="Cédula" aria-label="Search">
            <button class="btn btn-success" type="submit">Buscar</button>
        </form>
        </div>
        <br><br>
    <div class="panel panel-default">
        <!-- Default panel contents -->
        <table class="table table-responsive-md text-center">
            <thead class="thead-tomate">
            <tr>
                <th>Nr.</th>
                <th>Nombres y Apellidos</th>
                <th>Cédula</th>
                <th>Fecha</th>
                <th>Hora</th>
            </tr>
            </thead>
            <?php
                $i=1;
            ?>
            <?php $__currentLoopData = $tiempos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiempos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($tiempos->nombre.' '.$tiempos->apellido); ?></td>
                    <td><?php echo e($tiempos->cedula); ?></td>
                    <td><?php echo e($tiempos->fecha); ?></td>
                    <td><?php echo e($tiempos->horas); ?></td>
                <td><?php echo $tiempos->estado; ?></td>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/tiempo_reposicions/index.blade.php ENDPATH**/ ?>