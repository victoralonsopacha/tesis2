@php
    echo $reposicion;
@endphp
