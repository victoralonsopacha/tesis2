

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Mi Permiso</div>
        </div>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('permiso_profesors.shows')); ?>">Regresar</a>
        </div>
        <br><br>
        <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::model($permiso_profesor, ['method' => 'PATCH','route' => ['permiso_profesors.update', $permiso_profesor]]); ?>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <strong>Fecha de Inicio:</strong>
                <?php echo Form::date('fecha_inicio',null,['class' => 'form-control','readonly']); ?>

            </div>
            <div class="form-group">
                <strong>Hora Inicio:</strong>
                <?php echo Form::time('hora_inicio', \Carbon\Carbon::now(), array('class' => 'form-control','readonly')); ?>

            </div>
            <div class="form-group">
                <strong>Fecha Fin:</strong>
                <?php echo Form::date('fecha_fin', null, array('class' => 'form-control','readonly')); ?>

            </div>

            <div class="form-group">
                <strong>Hora Fin:</strong>
                <?php echo Form::time('hora_fin', null, array('class' => 'form-control','readonly')); ?>

            </div>
            <div class="form-group">
                <strong>Tipo Permiso:</strong>
                <?php echo Form::text('tipo_permiso', null, array('class' => 'form-control','readonly')); ?>

            </div>
            <?php if($permiso_profesor->estado == 1): ?>
                <div class="form-group">
                    <strong>Estado:</strong>
                    <?php echo Form::text('Aprobado', null, array('placeholder' => 'Aprobado','class' => 'form-control','readonly')); ?>

                </div>
            <?php endif; ?>

            <?php if($permiso_profesor->estado == 2): ?>
                <div class="form-group">
                    <strong>Estado:</strong>
                    <?php echo Form::text('Aprobado', null, array('placeholder' => 'Reprobado','class' => 'form-control','readonly')); ?>

                </div>
                <div class="form-group">
                    <strong>Observación del Inspector:</strong>
                    <?php echo Form::text('desaprobacion', null, array('class' => 'form-control','readonly')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <strong>Mi Observación:</strong>
                <?php echo Form::text('descripcion', null, array('class' => 'form-control','readonly')); ?>

            </div>
            <div class="form-group">
                <strong>Archivo Justificación:</strong><br>
                <img src="<?php echo e(asset("$permiso_profesor->file")); ?>" alt="" style="width:250px;height:250px;">
            </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permiso_profesors/show.blade.php ENDPATH**/ ?>