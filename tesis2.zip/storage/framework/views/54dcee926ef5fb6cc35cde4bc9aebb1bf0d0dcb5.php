<div class="panel panel-default">
    <div class="panel-heading">Permisos Aprobados</div>
    <table class="table table-responsive-md text-center">
        <thead class="thead-tomate">
        <tr>
            <th>Nr.</th>
            <th>Fecha Inicio</th>
            <th>Hora Inicio</th>
            <th>Fecha Finalización</th>
            <th>Fecha Finalización</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i=1;
        ?>
        <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permisoItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $permisoItem->fecha_inicio; ?></td>
                <td><?php echo $permisoItem->hora_inicio; ?></td>
                <td><?php echo $permisoItem->fecha_fin; ?></td>
                <td><?php echo $permisoItem->hora_fin; ?></td>
                <td>
                    <a href="<?php echo e(route('permiso_profesors.show', $permisoItem)); ?>" class="btn btn-xs btn-success"><i class="fa fa-eye" aria-hidden="true"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/permiso_profesors/form.blade.php ENDPATH**/ ?>