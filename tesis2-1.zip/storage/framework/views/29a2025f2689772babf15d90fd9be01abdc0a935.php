

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

    <h1>HORAS TOTALES</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

<div class="col-sm-6">
    <h1>HORAS TOTALES</h1>


<form action=""></form>

    <div class="card text-center">
        <div class="card-header">
          <ul class="nav nav-tabs card-header-tabs">
            <li class="nav-item">
                

                <?php $__currentLoopData = $consulta2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">Cedula</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-5 col-form-label"><?php echo e($itemconsulta2->cedula); ?></label>
                    </div>
                </div>      
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">Nombre</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-5 col-form-label"><?php echo e($itemconsulta2->nombre); ?></label>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">Apellido</label>
                    <div class="col-sm-6">
                        <label for="staticEmail" class="col-sm-5 col-form-label"><?php echo e($itemconsulta2->apellido); ?></label>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">HORAS TOTALES TRABAJADAS</label>
                    <div class="col-sm-6">
                        <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta2->tiempo_trabajado); ?>" readonly>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                <?php $__currentLoopData = $consulta4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">DIAS TOTALES TRABAJADOS</label>
                    <div class="col-sm-6">
                        <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta4->num_dias); ?> DIAS" readonly>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                <?php $__currentLoopData = $consulta3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group row">
                    <label for="staticEmail" class="col-sm-5 col-form-label">ATRASOS</label>
                    <div class="col-sm-6">
                        <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta3->retraso_trabajado); ?>" readonly>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
                <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>">Volver a Calcular</a>

            </li>

          </ul>

          
        </div>
      </div>
    </div>
<div class="col-sm-6">

      <h1>PERMISOS TOTALES</h1>


      <div class="card text-center">
          <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
              <li class="nav-item">
                  
                  
                       
                  <?php $__currentLoopData = $consulta7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row">
                      <label for="staticEmail" class="col-sm-5 col-form-label">HORAS TOTALES DE PERMISOS</label>
                      <div class="col-sm-6">
                          <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta7->tiempo_permiso); ?>" readonly>
                      </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $consulta8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row">
                      <label for="staticEmail" class="col-sm-5 col-form-label">CANTIDAD DE PERMISOS SOLICITADOS</label>
                      <div class="col-sm-6">
                          <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta8->cantidad_permisos); ?>" readonly>
                      </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php $__currentLoopData = $consulta5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row">
                      <label for="staticEmail" class="col-sm-5 col-form-label">PERMISOS APROBADOS</label>
                      <div class="col-sm-6">
                          <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta5->permisos); ?>" readonly>
  
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  </div>


                  <div class="form-group row">
                    <?php $__currentLoopData = $consulta6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemconsulta3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <label for="staticEmail" class="col-sm-5 col-form-label">PERMISOS SIN APROBAR</label>
                    <div class="col-sm-6">
                        <input type="input" class="form-control" name="date" value="<?php echo e($itemconsulta3->permisos); ?>" readonly>
                    </div>
                </div>
                
                

              </li>
  
            </ul>
          </div>
        </div>

        

    </div>

    <a href="<?php echo e(route('imprimir')); ?>">Imprime el archivo</a>

    <?php $__env->stopSection(); ?>










<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tesis2\resources\views//calculo_tiempos/total.blade.php ENDPATH**/ ?>