

<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading text-center">Gestión de Usuarios</div>
        </div>
        <div class="pull-left">
            <a class="btn btn-primary" href="<?php echo e(route('users.inactivos')); ?>">Ver usuarios inactivos</a>
        </div>
        <div class="pull-right">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-warning">Agregar nuevo usuario</a>
        </div>
        <br><br>
        <br>
        <div class="pull-right">
            <form method="POST" action="<?php echo e(route('users.find')); ?>" class="form-inline my-2 my-lg-0">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputName2">Buscar Por:</label>
                    <input name="nombre" class="form-control me-2" type="text" placeholder="Nombre" aria-label="Search">
                </div>
                <div class="form-group">
                    <input name="cedula" class="form-control me-2" type="number" placeholder="Cédula" aria-label="Search">
                </div>
                <button type="submit" class="btn btn-default">Buscar</button>
            </form>
        </div>
        <br><br>

    <?php echo $__env->make('partials.validationMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($usersl->isempty()): ?>
        <?php echo $__env->make('partials.validationAlertempty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
            <div class="panel panel-default">
                <table class="table table-responsive-md">
                    <thead class="thead-tomate">
                    <tr>
                        <th>Nr.</th>
                        <th>Nombres y Apellidos</th>
                        <th>Email</th>
                        <th>Cédula</th>
                        <th>Rol</th>
                        <th>Estado</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $usersl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $rolesl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($rol->model_id == $users->id): ?>
                                    <?php if($rol->role_id == $role->id): ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $users->name." ".$users->last_name; ?></td>
                                            <td><?php echo $users->email; ?>

                                            <td><?php echo $users->cedula; ?>

                                            <td><?php echo $role->name; ?></td>
                                            <td><span class="label label-primary">Activo</span></td>
                                            <td>
                                                <a class="btn btn-success btn-xs" href="<?php echo e(route('users.edit', $users->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('users.deactive', $users->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button class="btn btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas desactivar este usuario?')">
                                                                <span aria-hidden="true" class="glyphicon glyphicon-trash">
                                                                </span></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!--/.panel-default-->
        <?php endif; ?>
    </div><!--/.container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/users/activos.blade.php ENDPATH**/ ?>