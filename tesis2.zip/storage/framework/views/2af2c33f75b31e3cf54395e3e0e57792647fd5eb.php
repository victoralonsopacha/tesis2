<?php
    echo $reposicion;
?>
<?php /**PATH C:\Users\Jazmin\Documents\Tesis\2Repositorio\bk\20210303\tesis2\resources\views/tiempo_reposicions/calcular.blade.php ENDPATH**/ ?>